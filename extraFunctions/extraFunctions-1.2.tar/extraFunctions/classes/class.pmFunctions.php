<?php
/**
 * class.extraFunctions.pmFunctions.php
 *
 * Extra functions for use in ProcessMaker triggers and plugins.
 **/

////////////////////////////////////////////////////
// extraFunctions PM Functions
//
// Author:  Amos Batto
// Email:   amos@processmaker.com
// Created: 2018-04-04 on PM 3.2.1-Community
// Updated: 2018-04-24 (version 1.2)
//
// License: Public Domain
////////////////////////////////////////////////////

/**
 * Extra Functions
 * @class extraFunctions
 *
 * @name Extra Functions
 * @icon /plugin/extraFunctions.gif
 * @className class.extraFunctions.pmFunctions.php
 */


/**
 * @method
 *
 * Gets the unique ID of a user from the username
 *
 * @name PMFGetUidFromUsername
 * @label PMFGetUidFromUsername()
 * @link https://github.com/amosbatto/pmcommunity/tree/master/extraFunctions#pmfgetuidfromusername
 * 
 * @param string | $username='' | User's username | Optional. The username of a ProcessMaker user. If not included or set to an empty string, then will return the ID of the current logged user.
 *
 * @return string | @@userId | User's unique ID | It returns the user's unique ID; otherwise it returns FALSE if the username isn't found.
 */
function PMFGetUidFromUsername($username='')
{
    if (empty($username)) {
       if (isset($_SESSION['USER_LOGGED'])) {
          return $_SESSION['USER_LOGGED'];
       }
       else {
          return false;
       }
    }
    
    $c = new Criteria( 'workflow' );
    $c->clearSelectColumns();
    $c->addSelectColumn( UsersPeer::USR_UID );
    $c->add( UsersPeer::USR_USERNAME, $username );
    $rs = UsersPeer::doSelectRS( $c, Propel::getDbConnection('workflow_ro') );
    $rs->setFetchmode( ResultSet::FETCHMODE_ASSOC );
    $rs->next();
    if ($aRow = $rs->getRow()) {
        return $aRow['USR_UID'];
    }
    else {
        return false;
    }
}	


/************************************************************
Function to break time in seconds into days, minutes, hours and seconds.
Parameters:
   int $seconds:      The number of seconds.
   string $timeUnits: The unit of time which can be "seconds", "minutes", "hours", "days",
                      "array" or "string".
Return Value:
   Returns the time according to the $timeUnits. If "string", then returns something like
   "1 day 7 hours 0 minutes 34 seconds" or "45 minutes 1 second". Units which are set to 0 
   not included in the string.
   
   If "array", then returns something like:
   array(
     "days" => 1,
     "hours" => 7,
     "minutes" => 0,
     "seconds" => 34
   ) 
************************************************************/   
function timeBreakdown($seconds, $timeUnits='seconds') {
   $timeUnits = strtolower($timeUnits);
   switch ($timeUnits) {
      case 'seconds':
         return $seconds;
      case 'minutes':
         return $seconds/60;
      case 'hours':
         return $seconds/3600;
      case 'days':
         return $seconds/86400;
      case 'array':
      case 'string':
         $aTime = array();
         $aTime['days'] = (int) ($seconds / 86400);
         $remainder = $seconds % 86400;
         $aTime['hours'] = (int) ($remainder / 3600);
         $remainder = $remainder % 3600;
         $aTime['minutes'] = (int) ($remainder / 60);
         $aTime['seconds'] = $remainder % 60;
         if ($timeUnits == 'array')
            return $aTime;
         else {
            $sTime = '';
            if ($aTime['days'] > 1)
               $sTime = $aTime['days'].' days';
            elseif ($aTime['days'] == 1)
               $sTime = '1 day';             
            
            if ($aTime['hours'] > 1)
               $sTime .= (empty($sTime) ? '' : ' ') . $aTime['hours'].' hours';
            elseif ($aTime['hours'] == 1)
               $sTime .= (empty($sTime) ? '' : ' ') . '1 hour';
            elseif (!empty($sTime))
               $sTime .= ' 0 hours';  
               
            if ($aTime['minutes'] > 1)
               $sTime .= (empty($sTime) ? '' : ' ') . $aTime['minutes'].' minutes';
            elseif ($aTime['minutes'] == 1)
               $sTime .= (empty($sTime) ? '' : ' ') . '1 minute';
            elseif (!empty($sTime))
               $sTime .= ' 0 minutes';  
               
            if ($aTime['seconds'] > 1)
               $sTime .= (empty($sTime) ? '' : ' ') . $aTime['seconds'].' seconds';
            elseif ($aTime['seconds'] == 1)
               $sTime .= (empty($sTime) ? '' : ' ') . '1 second';
            elseif (!empty($sTime))
               $sTime .= ' 0 seconds';
               
            return $sTime;  
         }
      default: 
         throw new Exception("Unrecognized time unit '$timeUnits'");
   }
}            

/**
 * @method
 * 
 * Calculates the amount of time a task has taken, depending
 * on the calendar which is configured for the task or the assigned user.
 * 
 * @name PMFTaskDuration
 * @label PMFTaskDuration()
 * @link https://github.com/amosbatto/pmcommunity/tree/master/extraFunctions#pmftaskduration
 * 
 * @param string     | $startTime          | Time when task started | Datetime when task started in "YYYY-MM-DD HH:MM:SS" format.
 * @param string     | $endTime=''         | Time when task ends    | Optional. Datetime when task ends in "YYYY-MM-DD HH:MM:SS" format. Set to null if the task hasn't been completed, so that the current time will be used.
 * @param string     | $timeUnits='seconds'| Time unit returned     | Optional. The unit of time which is returned by the function, which can be: "seconds" (default), "minutes", "hours", "days", "string" or "array"
 * @param string(32) | $userUid=''         | User unique ID         | Optional. Unique ID of user assigned to the task. Default is the current logged-in user.
 * @param string(32) | $taskUid=''         | Task unique ID         | Unique ID of the task whose duration will be calculated. Default is the current task.
 * @param string(32) | $processUid=''      | Process unique ID      | Unique ID of the process. Default is the current process.
 *
 * @return float | @#timeElapsed | Task time duration | Returns the time in a floating point number (or array if $timeUnits is set to "array")
 */
function PMFTaskDuration($startTime, $endTime = null, $timeUnits = 'seconds',
   $userUid = null, $taskUid = null, $processUid = null) {
	
   if (empty($endTime)) {
      //change this line to work correctly for current time in the Enterprise Edition:
      $endTime = date("Y-m-d H:i:s"); 
   }
   if (empty($userUid) and isset($_SESSION['USER_LOGGED'])) {
      $userUid = $_SESSION['USER_LOGGED'];
   }
   if (empty($taskUid) and isset($_SESSION['TASK'])) {
      $taskUid = $_SESSION['TASK'];
   }   
   if (empty($processUid) and isset($_SESSION['PROCESS'])) {
      $processUid = $_SESSION['PROCESS'];
   }
      
   $g = new G();	   
   $g->LoadClass('calendar');
   $oCal = new Calendar();
   $oCal->getCalendar($userUid, $processUid, $taskUid);
   $oCal->getCalendarData();
   $seconds = $oCal->calculateDuration($startTime, $endTime);
   return timeBreakdown($seconds, $timeUnits);
}

/**
 * @method
 * 
 * calculates the date for a specified time duration based on the configured calendar 
 * for a specified user, task and process. In ProcessMaker, the calendar of the user 
 * has priority. If the user doesn't have a calendar, then the calendar of the task 
 * is used. If the task doesn't have a calendar, then the calendar of the process is used. 
 * 
 * @name PMFCalculateDate
 * @label PMFCalculateDate()
 * @link https://github.com/amosbatto/pmcommunity/tree/master/extraFunctions#pmfcalculatedate
 * 
 * @param string     | $startTime       | Datetime to start | Datetime in "YYYY-MM-DD HH:MM:SS" format from which to start.
 * @param float      | $duration        | Duration of time  | Number of $timeUnits.
 * @param string     | $timeUnits='DAYS'| Time unit         | Optional. The unit of time for the $duration, which can be 'DAYS' (default),'HOURS' or 'MINUTES'.
 * @param string(32) | $userUid=null    | User unique ID    | Optional. Unique ID of user assigned to the task, whose calendar will be used. Default is the current logged-in user.
 * @param string(32) | $taskUid=null    | Task unique ID    | Optional. Unique ID of the task whose calendar will be used if the user doesn't have an assigned calendar. Default is the current task.
 * @param string(32) | $processUid=null | Process unique ID | Optional. Unique ID of the process, whose calendar will be used if the task doesn't have an assigned calendar. Default is the current process.
 *
 * @return string    | @@endTime        | Datetime when duration completes | Returns the datetime in "YYYY-MM-DD HH:MM:SS" format when the time will complete.
 */ 
function PMFCalculateDate($startTime, $duration, $timeUnits = 'DAYS',
   $userUid = null, $taskUid = null, $processUid = null) 
{
   if (empty($userUid) and isset($_SESSION['USER_LOGGED'])) {
      $userUid = $_SESSION['USER_LOGGED'];
   }
   if (empty($taskUid) and isset($_SESSION['TASK'])) {
      $taskUid = $_SESSION['TASK'];
   }   
   if (empty($processUid) and isset($_SESSION['PROCESS'])) {
      $processUid = $_SESSION['PROCESS'];
   } 
   
   $g = new G();  
   $g->LoadClass('calendar');
   $oCal = new Calendar();
   $oCal->getCalendar($userUid, $processUid, $taskUid);
   $oCal->getCalendarData();
   $aDate = $oCal->calculateDate($startTime, $duration, $timeUnits);
   return $aDate['DUE_DATE'];
}


/*****************************************************
nextBpmnActivitiesRecursive() returns a list of the next activities in a BPMN process.
It is called recursively to get the tasks after gateways 
Parameters:
$uid: The unique ID of a task, subprocess or gateway
$aActivities: An array of activities for calling the function recursively. 
              Do not include when called the first time.
Return Value:
An array of unique IDs of tasks.
******************************************************/
function nextBpmnActivitiesRecursive($uid, $aActivities=array()) {
	$query = "SELECT * FROM BPMN_FLOW WHERE FLO_ELEMENT_ORIGIN='$uid'";
	$aFlows = executeQuery($query);
	
	if (!is_array($aFlows)) {
		throw new Exception("Cannot execute query: $query");
	}
	
	foreach ($aFlows as $aFlow) {
		if ($aFlow['FLO_ELEMENT_DEST_TYPE'] == 'bpmnActivity') {
			$aActivities[] = $aFlow['FLO_ELEMENT_DEST'];
		}
		elseif ($aFlow['FLO_ELEMENT_DEST_TYPE'] == 'bpmnGateway') {
			$aActivities2 = nextBpmnActivitiesRecursive($aFlow['FLO_ELEMENT_DEST'], $aActivities);
			$aActivities = array_merge($aActivities, $aActivities2);
		}
	}
	return array_unique($aActivities);
}


/*****************************************************
nextActivities() returns a list of the next activities (tasks and subprocesses) 
in a normal (2.X) process.
Parameters:
$uid: The unique ID of a task or subprocess

Return Value:
An array of unique IDs of the activities.
******************************************************/
function nextActivities($uid) {
	$query = "SELECT * FROM ROUTE WHERE TAS_UID='$uid'";
	$aRoutes = executeQuery($query);
	
	if (!is_array($aRoutes))
		throw new Exception("Cannot execute query: $query");
	
	$aActivities = array();
	foreach ($aRoutes as $aRoute) {
		//if no following task/subprocess:
		if ($aRoute['ROU_NEXT_TASK'] == '-1') {
			continue;
		}
		else {
			$aActivities[] = $aRoute['ROU_NEXT_TASK'];
		}
	}
	return $aActivities;
}

 
/**
 * @method
 * 
 * Returns a list of the next activities (tasks and subprocesses) in the process 
 * which come after a specified task or subprocess. 
 * 
 * @name PMFNextActivities
 * @label PMFNextActivities()
 * @link https://github.com/amosbatto/pmcommunity/tree/master/extraFunctions#pmfnextactivities
 * 
 * @param string(32) | $activityUid='' | Activity unique ID | Optional. The unique ID of a task or subprocess. If left blank, then set to the current activity.
 * 
 * @return array | $aActivities | List of next activities | Returns an array of associative arrays with information about the activities.
 */
function PMFNextActivities($activityUid='') {
   if (empty($activityUid)) {
      if (!isset($_SESSION['TASK'])) {
         throw new Exception("Need to set $activityUid, because @@TASK is not available."); 
      }
      $activityUid = $_SESSION['TASK'];
   }
      
	//call PMFActivityInfo() to error check if the activity exists
	PMFActivityInfo($activityUid);
	
	//if a BPMN process:
	require_once 'classes/model/BpmnActivity.php';
	$a = new BpmnActivity();
	if ($a->exists($activityUid)) {
		$aNextActs = nextBpmnActivitiesRecursive($activityUid);
	}
	//else a normal (2.X) process:
	else {
		$aNextActs = nextActivities($activityUid);
	}
	
	$aNextActsInfo = array();
	
	foreach($aNextActs as $nextActUid) {
		$aNextActsInfo[] = PMFActivityInfo($nextActUid);
	}
	return $aNextActsInfo;
}

/**
 * @method
 * 
 * Returns an array of information about a specified activity (task or subprocess).
 * 
 * @name PMFActivityInfo
 * @label PMFActivityInfo()
 * @link https://github.com/amosbatto/pmcommunity/tree/master/extraFunctions#pmfactivityinfo
 * 
 * @param string(32) | $activityUid='' | Activity unique ID | Optional. The unique ID of a task or subprocess. If left blank, then set to the current activity.
 * 
 * @return array | @=aActivity |  Information about the activity | Returns an associative array with information about the activity.
 */
function PMFActivityInfo($activityUid='') {
	require_once 'classes/model/SubProcess.php';
	require_once 'classes/model/Task.php';
	G::LoadClass('derivation'); //not necessary in triggers
   
   if (empty($activityUid)) {
      if (!isset($_SESSION['TASK'])) {
         throw new Exception("Need to set $activityUid, because @@TASK is not available."); 
      }
      $activityUid = $_SESSION['TASK'];
   }
	
	//check if a task:
	$t = new Task();
	if ($t->taskExists($activityUid)) {
		$aTask = $t->load($activityUid);
		$d = new Derivation();
		$aTask['ASSIGNED_USERS'] = $d->getAllUsersFromAnyTask($activityUid);
		return $aTask;
	}
	//check if a subprocess:
	$sp = new SubProcess();
	if ($sp->subProcessExists($activityUid)) {
		$aSubprocess = $sp->load($activityUid);
		return $aSubprocess;
	}
	else {
		throw new Exception("The activity with the ID '$activityUid' does not exist.");
		return null;
	}
}

/**
 * @method
 * 
 * Get the case counters for a user, meaning the number of To Do, Draft, 
 * Paused, Cancelled, Participated, Unassigned and Process Supervisor's Review 
 * cases for that user.
 * If getting the case counters for another user, then the logged-in user needs to
 * have the PM_ALLCASES permission in his/her role. 
 * 
 * @name PMFCaseCounters
 * @label PMFCaseCounters()
 * @link https://github.com/amosbatto/pmcommunity/tree/master/extraFunctions#pmfcasecounters
 * 
 * @param string(32) | $userUid='' | User unique ID | Optional. Unique ID of a user. If not included then will return the case counters for the current logged-in user.
 * 
 * @return array     | @=aCounters |  Array of case counters. | Returns an array with the number of cases for the following categories: array('to_do'=>X, 'draft'=>X, 'cancelled'=>X, 'sent'=>X, 'paused'=>X, 'completed'=>X, 'selfservice'=>X, 'to_revise'=>X)
 */
function PMFCaseCounters($userUid='')
{
   global $RBAC;
   
   if (empty($userUid)) {
      if (!isset($_SESSION['USER_LOGGED'])) {
         throw new Exception("Need to set the $userUid, because no @@USER_LOGGED available.");
      }
      $userUid = $_SESSION['USER_LOGGED'];
   }
   
   if (isset($_SESSION['USER_LOGGED']) and $userUid != $_SESSION['USER_LOGGED'] and
         $RBAC->userCanAccess('PM_ALLCASES') != 1) 
   {
       throw new Exception("Logged-in user needs the PM_ALLCASES permission to access ".
           "the case counters of other users.");
   }
   
   $aTypes = array('to_do', 'draft', 'cancelled', 'sent', 'paused', 'completed', 'selfservice', 'to_revise');            
   $oCase = new \ProcessMaker\BusinessModel\Cases();
   $aCount = $oCase->getListCounters($userUid, $aTypes);

   return $aCount;
   /*Returns an array with the number of cases in the following categories: 
     array(
       'to_do'      => X, //number of To Do cases
       'draft'      => X, //number of Draft cases
       'cancelled'  => X, //number of Cancelled cases
       'sent'       => X, //number of Participated cases
       'paused'     => X, //number of Paused cases
       'completed'  => X, //number of Completed cases
       'selfservice'=> X, //number of Unassigned cases (for tasks with 
                          //Self Service o Self Service Value Based Assignment)
       'to_revise'  =  X, //number of Process Supervisor > Review cases
     )
   */
} 

/**
 * @method
 * 
 * Executes a trigger in a specified case and task and by a specified user.
 * 
 * @name PMFExecuteTrigger
 * @label PMFExecuteTrigger()
 * @link https://github.com/amosbatto/pmcommunity/tree/master/extraFunctions#pmfexecutetrigger
 * 
 * @param string     | $triggerId | ID or title of trigger | The unique ID or title of the trigger to executed. Note that the trigger title is case sensitive. 
 * @param string(32) | $taskId='' | Task unique ID | Optional. Unique ID of the task where the trigger will be executed. Default is the current task.
 * @param string(32) | $caseId='' | Case unique ID | Optional. Unique ID of the case where the trigger will be executed. Default is the current case.
 * @param string(32) | $userId='' | User unique ID | Optional. Unique ID of user to execute the trigger. Default is the current logged user.
 *
 * @return int | $result | Return variable | Returns 1 if successful or 0 if an error or sets an error message in @@__ERROR__.
 */ 
function PMFExecuteTrigger($triggerId, $caseId='', $delIndex='', $userId='') {
   if (empty($caseId)) {
      if (!isset($_SESSION['APPLICATION'])) {
         throw new Exception('Need to specify $caseId in PMFExecuteTrigger(), because session doesn\'t have APPLICATION.');
      }
      $caseId = $_SESSION['APPLICATION'];
   }
   if (empty($delIndex)) {
      if (!isset($_SESSION['INDEX'])) {
         throw new Exception('Need to specify $delIndex in PMFExecuteTrigger(), because session doesn\'t have INDEX.');
      }
      $delIndex = $_SESSION['INDEX'];
   }   
   if (empty($userId)) {
      if (!isset($_SESSION['USER_LOGGED'])) {
         throw new Exception('Need to specify $userId in PMFExecuteTrigger(), because session doesn\'t have USER_LOGGED.');
      }
      $userId = $_SESSION['USER_LOGGED'];
   }
   
   //if trigger ID is not a 32 hexidecimal string, then assume it is a
   //trigger title and look up its unique ID: 
   if (!preg_match('/^[0-9a-f]{32}$/', $triggerId)) { 
      $aTriggers = PMFGetUidFromText($triggerId, 'TRI_TITLE');
      if (empty($aTriggers)) {
         throw new Exception("PMFExecuteTrigger() is unable to find the trigger '$triggerId'.");
      }
      $triggerId = $aTriggers[0];
   }   
   
   $g = new G();
   $g->LoadClass("wsBase");
   $g->LoadClass("pmFunctions");
   $oWS = new wsBase();
   $oRet = $oWS->executeTrigger($userId, $caseId, $triggerId, $delIndex); 
   
   if (isset($oRet->status_code) and $oRet->status_code == 0) {
      return 1;
   } else if (isset($oRet->message)) {
      throw new Exception($oRet->message);
      return 0;
   } else {
      return 0;
   }
}


