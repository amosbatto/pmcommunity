<?php
G::LoadClass("plugin");

class extraFunctionsPlugin extends PMPlugin
{
  
  
  public function extraFunctionsPlugin($sNamespace, $sFilename = null)
  {
    $res = parent::PMPlugin($sNamespace, $sFilename);
    $this->sFriendlyName = "Extra Functions";
    $this->sDescription  = "Extra ProcessMaker functions by Amos Batto (amos@processmaker.com)";
    $this->sPluginFolder = "extraFunctions";
    //$this->sSetupPage    = "setup";
    $this->iVersion      = 1.2;
    //$this->iPMVersion  = 321;
    $this->aWorkspaces   = null;
    //$this->aWorkspaces = array("os");
    
       
    return $res;
  }

  public function setup()
  {
    $this->registerPmFunction();
        
  }

  public function install()
  {

  }
  
  public function enable()
  {
    
  }

  public function disable()
  {
    
  }
  
}

$oPluginRegistry = &PMPluginRegistry::getSingleton();
$oPluginRegistry->registerPlugin("extraFunctions", __FILE__);
