<?php
/**
 * class.extraFunctions.pmFunctions.php
 *
 * Extra functions for use in ProcessMaker triggers and plugins.
 * *
 */

////////////////////////////////////////////////////
// extraFunctions PM Functions
//
// Author:  Amos Batto
// Email:   amos@processmaker.com
// Created: 2018-04-04 on PM 3.2.1-Community
// Updated: 2018-04-04
//
// License: Public Domain
////////////////////////////////////////////////////


/**************************************************************
Function to get the unique ID of a user from the username

Parameters:
   string $username: The username of a user
 
Return Value:
   Returns the unique ID of user; otherwise returns FALSE.
***************************************************************/
function PMFGetUidFromUsername($username)
{
	$c = new Criteria( 'workflow' );
    $c->clearSelectColumns();
    $c->addSelectColumn( UsersPeer::USR_UID );
    $c->add( UsersPeer::USR_USERNAME, $username );
    $rs = UsersPeer::doSelectRS( $c, Propel::getDbConnection('workflow_ro') );
    $rs->setFetchmode( ResultSet::FETCHMODE_ASSOC );
    $rs->next();
    if ($aRow = $rs->getRow()) {
        return $aRow['USR_UID'];
    }
    else {
        return false;
    }
}	


/************************************************************
Function to break time in seconds into days, minutes, hours and seconds.
Parameters:
   int $seconds:      The number of seconds.
   string $timeUnits: The unit of time which can be "seconds", "minutes", "hours", "days",
                      "array" or "string".
Return Value:
   Returns the time according to the $timeUnits. If "string", then returns something like
   "1 day 7 hours 0 minutes 34 seconds" or "45 minutes 1 second". Units which are set to 0 
   not included in the string.
   
   If "array", then returns something like:
   array(
     "days" => 1,
     "hours" => 7,
     "minutes" => 0,
     "seconds" => 34
   ) 
************************************************************/   
function timeBreakdown($seconds, $timeUnits='seconds') {
   $timeUnits = strtolower($timeUnits);
   switch ($timeUnits) {
      case 'seconds':
         return $seconds;
      case 'minutes':
         return $seconds/60;
      case 'hours':
         return $seconds/3600;
      case 'days':
         return $seconds/86400;
      case 'array':
      case 'string':
         $aTime = array();
         $aTime['days'] = (int) ($seconds / 86400);
         $remainder = $seconds % 86400;
         $aTime['hours'] = (int) ($remainder / 3600);
         $remainder = $remainder % 3600;
         $aTime['minutes'] = (int) ($remainder / 60);
         $aTime['seconds'] = $remainder % 60;
         if ($timeUnits == 'array')
            return $aTime;
         else {
            $sTime = '';
            if ($aTime['days'] > 1)
               $sTime = $aTime['days'].' days';
            elseif ($aTime['days'] == 1)
               $sTime = '1 day';             
            
            if ($aTime['hours'] > 1)
               $sTime .= (empty($sTime) ? '' : ' ') . $aTime['hours'].' hours';
            elseif ($aTime['hours'] == 1)
               $sTime .= (empty($sTime) ? '' : ' ') . '1 hour';
            elseif (!empty($sTime))
               $sTime .= ' 0 hours';  
               
            if ($aTime['minutes'] > 1)
               $sTime .= (empty($sTime) ? '' : ' ') . $aTime['minutes'].' minutes';
            elseif ($aTime['minutes'] == 1)
               $sTime .= (empty($sTime) ? '' : ' ') . '1 minute';
            elseif (!empty($sTime))
               $sTime .= ' 0 minutes';  
               
            if ($aTime['seconds'] > 1)
               $sTime .= (empty($sTime) ? '' : ' ') . $aTime['seconds'].' seconds';
            elseif ($aTime['seconds'] == 1)
               $sTime .= (empty($sTime) ? '' : ' ') . '1 second';
            elseif (!empty($sTime))
               $sTime .= ' 0 seconds';
               
            return $sTime;  
         }
      default: 
         throw new Exception("Unrecognized time unit '$timeUnits'");
   }
}            

/********************************
PMFTaskDuration() calculates the amount of time a task has taken, depending
on the calendar which is configured for the task or the assigned user.
Parameters:
  $startTime:  Time when task started in YYYY-MM-DD HH:MM:SS format.
  $endTime:    Time when the task ended in YYYY-MM-DD HH:MM:SS format. 
               If left blank or not included, then set to current time
  $timeUnits:  The unit of time which is returned by the function, which can be:
               "seconds" (default), "minutes", "hours", "days", "string" or "array"
  $userUid:    Unique ID of user assigned to the task. Default is the 
               current logged-in user.
  $taskUid:    Unique ID of the task whose duration will be calculated. 
               Default is the current task.
  $processUid: Unique ID of the process. Default is the current process.  

Return Value:
  Floating point number (or array if $timeUnits is set to "array")
**********************************************************************/
function PMFTaskDuration($startTime, $endTime = null, $timeUnits = 'seconds',
   $userUid = null, $taskUid = null, $processUid = null) {
	
   if (empty($endTime)) {
      //change this line to work correctly for current time in the Enterprise Edition:
      $endTime = date("Y-m-d H:i:s"); 
   }
   if (empty($userUid) and isset($_SESSION['USER_LOGGED'])) {
      $userUid = $_SESSION['USER_LOGGED'];
   }
   if (empty($taskUid) and isset($_SESSION['TASK'])) {
      $taskUid = $_SESSION['TASK'];
   }   
   if (empty($processUid) and isset($_SESSION['PROCESS'])) {
      $processUid = $_SESSION['PROCESS'];
   }
      
   $g = new G();	   
   $g->LoadClass('calendar');
   $oCal = new Calendar();
   $oCal->getCalendar($userUid, $processUid, $taskUid);
   $oCal->getCalendarData();
   $seconds = $oCal->calculateDuration($startTime, $endTime);
   return timeBreakdown($seconds, $timeUnits);
}

 

/*****************************************************************************
PMFCalculateDate() calculates the date for a specified time duration based 
on the configured calendar for a specified user, task and process. In
ProcessMaker, the calendar of the user has priority. If the user doesn't have
a calendar, then the calendar of the task is used. If the task doesn't have a 
calendar, then the calendar of the process is used. 

Parameters:
  string $startTime:  Datetime in "YYYY-MM-DD HH:MM:SS" format from which to start.
  float  $duration:   Number of time units to add to the $startTime.
  string $timeUnits:  The unit of time for the $duration, which can be 'DAYS' (default)
                      'HOURS' or 'MINUTES'.
  string $userUid:    Unique ID of user assigned to the task. Default is the 
                      current logged-in user.
  string $taskUid:    Unique ID of the task whose duration will be calculated. 
                      Default is the current task.
  string $processUid: Unique ID of the process. Default is the current process.  
  
Return Value:
  A string representing the calculated datetime in "YYYY-MM-DD HH:MM:SS" format.
******************************************************************************/
function PMFCalculateDate($startTime, $duration, $timeUnits = 'DAYS',
   $userUid = null, $taskUid = null, $processUid = null) 
{
   if (empty($userUid) and isset($_SESSION['USER_LOGGED'])) {
      $userUid = $_SESSION['USER_LOGGED'];
   }
   if (empty($taskUid) and isset($_SESSION['TASK'])) {
      $taskUid = $_SESSION['TASK'];
   }   
   if (empty($processUid) and isset($_SESSION['PROCESS'])) {
      $processUid = $_SESSION['PROCESS'];
   } 
   
   $g = new G();  
   $g->LoadClass('calendar');
   $oCal = new Calendar();
   $oCal->getCalendar($userUid, $processUid, $taskUid);
   $oCal->getCalendarData();
   $aDate = $oCal->calculateDate($startTime, $duration, $timeUnits);
   return $aDate['DUE_DATE'];
}


/*****************************************************
nextBpmnActivitiesRecursive() returns a list of the next activities in a BPMN process.
It is called recursively to get the tasks after gateways 
Parameters:
$uid: The unique ID of a task, subprocess or gateway
$aActivities: An array of activities for calling the function recursively. 
              Do not include when called the first time.
Return Value:
An array of unique IDs of tasks.
******************************************************/
function nextBpmnActivitiesRecursive($uid, $aActivities=array()) {
	$query = "SELECT * FROM BPMN_FLOW WHERE FLO_ELEMENT_ORIGIN='$uid'";
	$aFlows = executeQuery($query);
	
	if (!is_array($aFlows)) {
		throw new Exception("Cannot execute query: $query");
	}
	
	foreach ($aFlows as $aFlow) {
		if ($aFlow['FLO_ELEMENT_DEST_TYPE'] == 'bpmnActivity') {
			$aActivities[] = $aFlow['FLO_ELEMENT_DEST'];
		}
		elseif ($aFlow['FLO_ELEMENT_DEST_TYPE'] == 'bpmnGateway') {
			$aActivities2 = nextBpmnActivitiesRecursive($aFlow['FLO_ELEMENT_DEST'], $aActivities);
			$aActivities = array_merge($aActivities, $aActivities2);
		}
	}
	return array_unique($aActivities);
}


/*****************************************************
nextActivities() returns a list of the next activities (tasks and subprocesses) 
in a normal (2.X) process.
Parameters:
$uid: The unique ID of a task or subprocess

Return Value:
An array of unique IDs of the activities.
******************************************************/
function nextActivities($uid) {
	$query = "SELECT * FROM ROUTE WHERE TAS_UID='$uid'";
	$aRoutes = executeQuery($query);
	
	if (!is_array($aRoutes))
		throw new Exception("Cannot execute query: $query");
	
	$aActivities = array();
	foreach ($aRoutes as $aRoute) {
		//if no following task/subprocess:
		if ($aRoute['ROU_NEXT_TASK'] == '-1') {
			continue;
		}
		else {
			$aActivities[] = $aRoute['ROU_NEXT_TASK'];
		}
	}
	return $aActivities;
}

/*****************************************************
PMFNextActivities() returns a list of the next activities (tasks and subprocesses)
in the process which come after a specified task or subprocess. 
Parameters:
$uid: The unique ID of an activity (task or subprocess). 
Return Value:
A array of associative arrays with information about the activities
******************************************************/
function PMFNextActivities($activityUid) {
	//call PMFActivityInfo() to error check if the activity exists
	PMFActivityInfo($activityUid);
	
	//if a BPMN process:
	require_once 'classes/model/BpmnActivity.php';
	$a = new BpmnActivity();
	if ($a->exists($activityUid)) {
		$aNextActs = nextBpmnActivitiesRecursive($activityUid);
	}
	//else a normal (2.X) process:
	else {
		$aNextActs = nextActivities($activityUid);
	}
	
	$aNextActsInfo = array();
	
	foreach($aNextActs as $nextActUid) {
		$aNextActsInfo[] = PMFActivityInfo($nextActUid);
	}
	return $aNextActsInfo;
}

/*****************************************************
PMFActivityInfo() returns an array of information about an activity 
(tasks or subprocesses). 
Parameters:
$uid: The unique ID of an activity (task or subprocess). 
Return Value:
A array of information about the specified activity.
******************************************************/
function PMFActivityInfo($activityUid) {
	require_once 'classes/model/SubProcess.php';
	require_once 'classes/model/Task.php';
	G::LoadClass('derivation'); //not necessary in triggers
	
	//check if a task:
	$t = new Task();
	if ($t->taskExists($activityUid)) {
		$aTask = $t->load($activityUid);
		$d = new Derivation();
		$aTask['ASSIGNED_USERS'] = $d->getAllUsersFromAnyTask($activityUid);
		return $aTask;
	}
	//check if a subprocess:
	$sp = new SubProcess();
	if ($sp->subProcessExists($activityUid)) {
		$aSubprocess = $sp->load($activityUid);
		return $aSubprocess;
	}
	else {
		throw new Exception("The activity with the ID '$activityUid' does not exist.");
		return null;
	}
}



