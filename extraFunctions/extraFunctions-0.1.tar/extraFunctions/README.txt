The extraFunctions plugin provides useful functions that can be be used in 
ProcessMaker triggers and plugins. 



PMFGetUidFromUsername() gets the unique ID of a user from the username.

Parameters:
   string $username: The username of a user
 
Return Value:
   Returns the unique ID of user; otherwise returns FALSE.

Example 1:
The process designer needs to assign the next task in the process based on the 
order amount. If the amount is over 500, then the order needs to be approved 
by the district manager John Doe. If the order is less than 500, then the order 
needs to be approved by the local manager Jane Row:
-----------
if (!empty(@#orderAmount) and @#orderAmount >= 500) { 
   @@nextAssignedUser = PMFGetUidFromUsername("johndoe");
} else {
   @@nextAssignedUser = PMFGetUidFromUsername("janerow");
}
-----------

Example 2:
This function is also used when creating new cases that are assigned to a particular user.
In this example, a new case needs to be created which is assigned to the district manager 
if there are observations in the case:
-------------
if (isset(@@observations) and trim(@@observations) != '') {
   PMFNewCase($processId, PMFGetUidFromUsername("johndoe"), $taskId, 
      array("observations"=>@@observations));
}
-------------


PMFCalculateDate() calculates the date for a specified time duration based 
on the configured calendar for a specified user, task and process. In
ProcessMaker, the calendar of the user has priority. If the user doesn't have
a calendar, then the calendar of the task is used. If the task doesn't have a 
calendar, then the calendar of the process is used. 

Parameters:
  string $startTime:  Datetime in "YYYY-MM-DD HH:MM:SS" format from which to start.
  float  $duration:   Number of time units to add to the $startTime.
  string $timeUnits:  The unit of time for the $duration, which can be:
                      'DAYS' (default), 'HOURS' or 'MINUTES'.
  string $userUid:    Unique ID of user assigned to the task. Default is the 
                      current logged-in user.
  string $taskUid:    Unique ID of the task whose duration will be calculated. 
                      Default is the current task.
  string $processUid: Unique ID of the process. Default is the current process.  
  
Return Value:
  A string representing the calculated datetime in "YYYY-MM-DD HH:MM:SS" format.

Example:
Get the date in 10 working days using configured calendar for the current user and task:
---------------
@@date = PMFCalculateDate("2017-04-04 12:30:20", 10, "DAYS"); 
---------------


PMFTaskDuration() calculates the amount of time a task has taken, depending
on the calendar which is configured for the task or the assigned user.

Parameters:
  $startTime:  Time when task started in YYYY-MM-DD HH:MM:SS format.
  $endTime:    Time when the task ended in YYYY-MM-DD HH:MM:SS format. 
               If left blank or not included, then set to current time
  $timeUnits:  The unit of time which is returned by the function, which can be:
               "seconds" (default), "minutes", "hours", "days", "string" or "array"
  $userUid:    Unique ID of user assigned to the task. Default is the 
               current logged-in user.
  $taskUid:    Unique ID of the task whose duration will be calculated. 
               Default is the current task.
  $processUid: Unique ID of the process. Default is the current process.  

Return Value:
  Floating point number (or array if $timeUnits is set to "array")

Example1:
Check how much time has elapsed in the current task:
-------------
$c = new Cases();
$aCase = $c->LoadCase(@@APPLICATION, @%INDEX);
@%TaskSeconds = PMFTaskDuration($aCase['DEL_DELEGATE_DATE']);
-------------

Example2:
Display a grid of tasks, sorted by task and user:
-------------
$sql = "SELECT PRO_UID, TAS_UID, USR_UID, DEL_DELEGATE_DATE, DEL_FINISH_DATE
   FROM APP_DELEGATION WHERE DEL_THREAD_STATUS='CLOSED' GROUP BY TAS_UID, USR_UID";
$aTasks = executeQuery($sql);

//Calculate task times:
for ($i=1; $i <= count($aTasks); $i++) {
   $aTasks[$i]['TASK_TIME'] = PMFTaskDuration(
      $aTasks[$i]['USR_UID'],
      $aTasks[$i]['PRO_UID'],
      $aTasks[$i]['TAS_UID'],
      $aTasks[$i]['DEL_DELEGATE_DATE'],
      $aTasks[$i]['DEL_FINISH_DATE'],
      'string'
   );         
}
@=TasksGrid = $aTasks;
-------------



PMFActivityInfo() returns an array of information about an activity 
which can be a task or subprocess. 

Parameters:
$uid: The unique ID of an activity (task or subprocess).
 
Return Value:
A associative array of information about the specified activity.

Example:
Get the expected time to complete the current task in the current case:
----------------
$taskId = @@TASK;
$aTaskInfo = PMFActivityInfo($taskId);
@@taskDuration = $aTaskInfo['TAS_DURATION'] .' '. $aTaskInfo['TAS_TIMEUNIT'];
----------------

In this example $aTaskInfo contains:
----------------
  array(55) {
    ["PRO_UID"]=>
    string(32) "525089953576c664761a208010895181"
    ["TAS_UID"]=>
    string(32) "173419697576c697007da98073154447"
    ["TAS_TYPE"]=>
    string(6) "NORMAL"
    ["TAS_DURATION"]=>
    float(1)
    ["TAS_DELAY_TYPE"]=>
    string(0) ""
    ["TAS_TEMPORIZER"]=>
    float(0)
    ["TAS_TYPE_DAY"]=>
    string(0) ""
    ["TAS_TIMEUNIT"]=>
    string(4) "DAYS"
    ["TAS_ALERT"]=>
    string(5) "FALSE"
    ["TAS_PRIORITY_VARIABLE"]=>
    string(0) ""
    ["TAS_ASSIGN_TYPE"]=>
    string(8) "BALANCED"
    ["TAS_ASSIGN_VARIABLE"]=>
    string(30) "@@SYS_NEXT_USER_TO_BE_ASSIGNED"
    ["TAS_GROUP_VARIABLE"]=>
    NULL
    ["TAS_MI_INSTANCE_VARIABLE"]=>
    string(24) "@@SYS_VAR_TOTAL_INSTANCE"
    ["TAS_MI_COMPLETE_VARIABLE"]=>
    string(34) "@@SYS_VAR_TOTAL_INSTANCES_COMPLETE"
    ["TAS_ASSIGN_LOCATION"]=>
    string(5) "FALSE"
    ["TAS_ASSIGN_LOCATION_ADHOC"]=>
    string(5) "FALSE"
    ["TAS_TRANSFER_FLY"]=>
    string(5) "FALSE"
    ["TAS_LAST_ASSIGNED"]=>
    string(1) "0"
    ["TAS_USER"]=>
    string(1) "0"
    ["TAS_CAN_UPLOAD"]=>
    string(5) "FALSE"
    ["TAS_VIEW_UPLOAD"]=>
    string(5) "FALSE"
    ["TAS_VIEW_ADDITIONAL_DOCUMENTATION"]=>
    string(5) "FALSE"
    ["TAS_CAN_CANCEL"]=>
    string(5) "FALSE"
    ["TAS_OWNER_APP"]=>
    string(5) "FALSE"
    ["STG_UID"]=>
    string(0) ""
    ["TAS_CAN_PAUSE"]=>
    string(5) "FALSE"
    ["TAS_CAN_SEND_MESSAGE"]=>
    string(4) "TRUE"
    ["TAS_CAN_DELETE_DOCS"]=>
    string(5) "FALSE"
    ["TAS_SELF_SERVICE"]=>
    string(5) "FALSE"
    ["TAS_START"]=>
    string(5) "FALSE"
    ["TAS_TO_LAST_USER"]=>
    string(5) "FALSE"
    ["TAS_SEND_LAST_EMAIL"]=>
    string(5) "FALSE"
    ["TAS_DERIVATION"]=>
    string(6) "NORMAL"
    ["TAS_POSX"]=>
    int(444)
    ["TAS_POSY"]=>
    int(65)
    ["TAS_WIDTH"]=>
    int(110)
    ["TAS_HEIGHT"]=>
    int(60)
    ["TAS_COLOR"]=>
    string(0) ""
    ["TAS_EVN_UID"]=>
    string(0) ""
    ["TAS_BOUNDARY"]=>
    string(0) ""
    ["TAS_DERIVATION_SCREEN_TPL"]=>
    string(0) ""
    ["TAS_SELFSERVICE_TIMEOUT"]=>
    int(0)
    ["TAS_SELFSERVICE_TIME"]=>
    string(0) ""
    ["TAS_SELFSERVICE_TIME_UNIT"]=>
    string(0) ""
    ["TAS_SELFSERVICE_TRIGGER_UID"]=>
    string(0) ""
    ["TAS_SELFSERVICE_EXECUTION"]=>
    string(10) "EVERY_TIME"
    ["TAS_TITLE"]=>
    string(8) "Level2-1"
    ["TAS_DESCRIPTION"]=>
    string(0) ""
    ["TAS_DEF_TITLE"]=>
    string(0) ""
    ["TAS_DEF_DESCRIPTION"]=>
    string(0) ""
    ["TAS_DEF_PROC_CODE"]=>
    string(0) ""
    ["TAS_DEF_MESSAGE"]=>
    string(0) ""
    ["TAS_DEF_SUBJECT_MESSAGE"]=>
    string(0) ""
    ["ASSIGNED_USERS"]=>
    array(0) {
    }
  }  
-----------------


PMFActivityInfo() will return an array like this for a subprocess:
-----------------
 array(55) {
    ["PRO_UID"]=>
    string(32) "525089953576c664761a208010895181"
    ["TAS_UID"]=>
    string(32) "789438304576d6eda1d4ea7008448515"
    ["TAS_TYPE"]=>
    string(10) "SUBPROCESS"
    ["TAS_DURATION"]=>
    float(1)
    ["TAS_DELAY_TYPE"]=>
    string(0) ""
    ["TAS_TEMPORIZER"]=>
    float(0)
    ["TAS_TYPE_DAY"]=>
    string(0) ""
    ["TAS_TIMEUNIT"]=>
    string(4) "DAYS"
    ["TAS_ALERT"]=>
    string(5) "FALSE"
    ["TAS_PRIORITY_VARIABLE"]=>
    string(0) ""
    ["TAS_ASSIGN_TYPE"]=>
    string(8) "BALANCED"
    ["TAS_ASSIGN_VARIABLE"]=>
    string(30) "@@SYS_NEXT_USER_TO_BE_ASSIGNED"
    ["TAS_GROUP_VARIABLE"]=>
    NULL
    ["TAS_MI_INSTANCE_VARIABLE"]=>
    string(24) "@@SYS_VAR_TOTAL_INSTANCE"
    ["TAS_MI_COMPLETE_VARIABLE"]=>
    string(34) "@@SYS_VAR_TOTAL_INSTANCES_COMPLETE"
    ["TAS_ASSIGN_LOCATION"]=>
    string(5) "FALSE"
    ["TAS_ASSIGN_LOCATION_ADHOC"]=>
    string(5) "FALSE"
    ["TAS_TRANSFER_FLY"]=>
    string(5) "FALSE"
    ["TAS_LAST_ASSIGNED"]=>
    string(1) "0"
    ["TAS_USER"]=>
    string(1) "0"
    ["TAS_CAN_UPLOAD"]=>
    string(5) "FALSE"
    ["TAS_VIEW_UPLOAD"]=>
    string(5) "FALSE"
    ["TAS_VIEW_ADDITIONAL_DOCUMENTATION"]=>
    string(5) "FALSE"
    ["TAS_CAN_CANCEL"]=>
    string(5) "FALSE"
    ["TAS_OWNER_APP"]=>
    string(5) "FALSE"
    ["STG_UID"]=>
    string(0) ""
    ["TAS_CAN_PAUSE"]=>
    string(5) "FALSE"
    ["TAS_CAN_SEND_MESSAGE"]=>
    string(4) "TRUE"
    ["TAS_CAN_DELETE_DOCS"]=>
    string(5) "FALSE"
    ["TAS_SELF_SERVICE"]=>
    string(5) "FALSE"
    ["TAS_START"]=>
    string(5) "FALSE"
    ["TAS_TO_LAST_USER"]=>
    string(5) "FALSE"
    ["TAS_SEND_LAST_EMAIL"]=>
    string(5) "FALSE"
    ["TAS_DERIVATION"]=>
    string(6) "NORMAL"
    ["TAS_POSX"]=>
    int(380)
    ["TAS_POSY"]=>
    int(475)
    ["TAS_WIDTH"]=>
    int(110)
    ["TAS_HEIGHT"]=>
    int(60)
    ["TAS_COLOR"]=>
    string(0) ""
    ["TAS_EVN_UID"]=>
    string(0) ""
    ["TAS_BOUNDARY"]=>
    string(0) ""
    ["TAS_DERIVATION_SCREEN_TPL"]=>
    string(0) ""
    ["TAS_SELFSERVICE_TIMEOUT"]=>
    int(0)
    ["TAS_SELFSERVICE_TIME"]=>
    string(0) ""
    ["TAS_SELFSERVICE_TIME_UNIT"]=>
    string(0) ""
    ["TAS_SELFSERVICE_TRIGGER_UID"]=>
    string(0) ""
    ["TAS_SELFSERVICE_EXECUTION"]=>
    string(10) "EVERY_TIME"
    ["TAS_TITLE"]=>
    string(22) "Select cases to reopen"
    ["TAS_DESCRIPTION"]=>
    string(0) ""
    ["TAS_DEF_TITLE"]=>
    string(0) ""
    ["TAS_DEF_DESCRIPTION"]=>
    string(0) ""
    ["TAS_DEF_PROC_CODE"]=>
    string(0) ""
    ["TAS_DEF_MESSAGE"]=>
    string(0) ""
    ["TAS_DEF_SUBJECT_MESSAGE"]=>
    string(0) ""
    ["ASSIGNED_USERS"]=>
    array(0) {
    }
  }  
-------------


PMFNextActivities() returns a list of the next activities (tasks and subprocesses)
in the process which come after a specified task or subprocess. It works with 
both BPMN and normal processes.

Parameters:
$uid: The unique ID of an activity (task or subprocess). 

Return Value:
A array of associative arrays with information about the activities.

Example:
Get the names of the tasks following the current task in the case to display 
in a textarea:
---------------------
$taskId = @@TASK;
$aTasks = PMFNextActivities($taskId);
@@nextTasks = '';

foreach ($aTasks as $aTask) {
   @@nextTasks .= (empty(@@nextTasks) ? '' : "\n") . $aTask['TAS_TITLE'];
} 
---------------------

When PMFNextActivities() is executed, it will return an array like this:
---------------
array(6) {
  [0]=>
  array(55) {
    ["PRO_UID"]=>
    string(32) "525089953576c664761a208010895181"
    ["TAS_UID"]=>
    string(32) "789438304576d6eda1d4ea7008448515"
    ["TAS_TYPE"]=>
    string(10) "SUBPROCESS"
    ["TAS_DURATION"]=>
    float(1)
    ["TAS_DELAY_TYPE"]=>
    string(0) ""
    ["TAS_TEMPORIZER"]=>
    float(0)
    ["TAS_TYPE_DAY"]=>
    string(0) ""
    ["TAS_TIMEUNIT"]=>
    string(4) "DAYS"
    ["TAS_ALERT"]=>
    string(5) "FALSE"
    ["TAS_PRIORITY_VARIABLE"]=>
    string(0) ""
    ["TAS_ASSIGN_TYPE"]=>
    string(8) "BALANCED"
    ["TAS_ASSIGN_VARIABLE"]=>
    string(30) "@@SYS_NEXT_USER_TO_BE_ASSIGNED"
    ["TAS_GROUP_VARIABLE"]=>
    NULL
    ["TAS_MI_INSTANCE_VARIABLE"]=>
    string(24) "@@SYS_VAR_TOTAL_INSTANCE"
    ["TAS_MI_COMPLETE_VARIABLE"]=>
    string(34) "@@SYS_VAR_TOTAL_INSTANCES_COMPLETE"
    ["TAS_ASSIGN_LOCATION"]=>
    string(5) "FALSE"
    ["TAS_ASSIGN_LOCATION_ADHOC"]=>
    string(5) "FALSE"
    ["TAS_TRANSFER_FLY"]=>
    string(5) "FALSE"
    ["TAS_LAST_ASSIGNED"]=>
    string(1) "0"
    ["TAS_USER"]=>
    string(1) "0"
    ["TAS_CAN_UPLOAD"]=>
    string(5) "FALSE"
    ["TAS_VIEW_UPLOAD"]=>
    string(5) "FALSE"
    ["TAS_VIEW_ADDITIONAL_DOCUMENTATION"]=>
    string(5) "FALSE"
    ["TAS_CAN_CANCEL"]=>
    string(5) "FALSE"
    ["TAS_OWNER_APP"]=>
    string(5) "FALSE"
    ["STG_UID"]=>
    string(0) ""
    ["TAS_CAN_PAUSE"]=>
    string(5) "FALSE"
    ["TAS_CAN_SEND_MESSAGE"]=>
    string(4) "TRUE"
    ["TAS_CAN_DELETE_DOCS"]=>
    string(5) "FALSE"
    ["TAS_SELF_SERVICE"]=>
    string(5) "FALSE"
    ["TAS_START"]=>
    string(5) "FALSE"
    ["TAS_TO_LAST_USER"]=>
    string(5) "FALSE"
    ["TAS_SEND_LAST_EMAIL"]=>
    string(5) "FALSE"
    ["TAS_DERIVATION"]=>
    string(6) "NORMAL"
    ["TAS_POSX"]=>
    int(380)
    ["TAS_POSY"]=>
    int(475)
    ["TAS_WIDTH"]=>
    int(110)
    ["TAS_HEIGHT"]=>
    int(60)
    ["TAS_COLOR"]=>
    string(0) ""
    ["TAS_EVN_UID"]=>
    string(0) ""
    ["TAS_BOUNDARY"]=>
    string(0) ""
    ["TAS_DERIVATION_SCREEN_TPL"]=>
    string(0) ""
    ["TAS_SELFSERVICE_TIMEOUT"]=>
    int(0)
    ["TAS_SELFSERVICE_TIME"]=>
    string(0) ""
    ["TAS_SELFSERVICE_TIME_UNIT"]=>
    string(0) ""
    ["TAS_SELFSERVICE_TRIGGER_UID"]=>
    string(0) ""
    ["TAS_SELFSERVICE_EXECUTION"]=>
    string(10) "EVERY_TIME"
    ["TAS_TITLE"]=>
    string(22) "Select cases to reopen"
    ["TAS_DESCRIPTION"]=>
    string(0) ""
    ["TAS_DEF_TITLE"]=>
    string(0) ""
    ["TAS_DEF_DESCRIPTION"]=>
    string(0) ""
    ["TAS_DEF_PROC_CODE"]=>
    string(0) ""
    ["TAS_DEF_MESSAGE"]=>
    string(0) ""
    ["TAS_DEF_SUBJECT_MESSAGE"]=>
    string(0) ""
    ["ASSIGNED_USERS"]=>
    array(0) {
    }
  }
  [1]=>
  array(55) {
    ["PRO_UID"]=>
    string(32) "525089953576c664761a208010895181"
    ["TAS_UID"]=>
    string(32) "173419697576c697007da98073154447"
    ["TAS_TYPE"]=>
    string(6) "NORMAL"
    ["TAS_DURATION"]=>
    float(1)
    ["TAS_DELAY_TYPE"]=>
    string(0) ""
    ["TAS_TEMPORIZER"]=>
    float(0)
    ["TAS_TYPE_DAY"]=>
    string(0) ""
    ["TAS_TIMEUNIT"]=>
    string(4) "DAYS"
    ["TAS_ALERT"]=>
    string(5) "FALSE"
    ["TAS_PRIORITY_VARIABLE"]=>
    string(0) ""
    ["TAS_ASSIGN_TYPE"]=>
    string(8) "BALANCED"
    ["TAS_ASSIGN_VARIABLE"]=>
    string(30) "@@SYS_NEXT_USER_TO_BE_ASSIGNED"
    ["TAS_GROUP_VARIABLE"]=>
    NULL
    ["TAS_MI_INSTANCE_VARIABLE"]=>
    string(24) "@@SYS_VAR_TOTAL_INSTANCE"
    ["TAS_MI_COMPLETE_VARIABLE"]=>
    string(34) "@@SYS_VAR_TOTAL_INSTANCES_COMPLETE"
    ["TAS_ASSIGN_LOCATION"]=>
    string(5) "FALSE"
    ["TAS_ASSIGN_LOCATION_ADHOC"]=>
    string(5) "FALSE"
    ["TAS_TRANSFER_FLY"]=>
    string(5) "FALSE"
    ["TAS_LAST_ASSIGNED"]=>
    string(1) "0"
    ["TAS_USER"]=>
    string(1) "0"
    ["TAS_CAN_UPLOAD"]=>
    string(5) "FALSE"
    ["TAS_VIEW_UPLOAD"]=>
    string(5) "FALSE"
    ["TAS_VIEW_ADDITIONAL_DOCUMENTATION"]=>
    string(5) "FALSE"
    ["TAS_CAN_CANCEL"]=>
    string(5) "FALSE"
    ["TAS_OWNER_APP"]=>
    string(5) "FALSE"
    ["STG_UID"]=>
    string(0) ""
    ["TAS_CAN_PAUSE"]=>
    string(5) "FALSE"
    ["TAS_CAN_SEND_MESSAGE"]=>
    string(4) "TRUE"
    ["TAS_CAN_DELETE_DOCS"]=>
    string(5) "FALSE"
    ["TAS_SELF_SERVICE"]=>
    string(5) "FALSE"
    ["TAS_START"]=>
    string(5) "FALSE"
    ["TAS_TO_LAST_USER"]=>
    string(5) "FALSE"
    ["TAS_SEND_LAST_EMAIL"]=>
    string(5) "FALSE"
    ["TAS_DERIVATION"]=>
    string(6) "NORMAL"
    ["TAS_POSX"]=>
    int(444)
    ["TAS_POSY"]=>
    int(65)
    ["TAS_WIDTH"]=>
    int(110)
    ["TAS_HEIGHT"]=>
    int(60)
    ["TAS_COLOR"]=>
    string(0) ""
    ["TAS_EVN_UID"]=>
    string(0) ""
    ["TAS_BOUNDARY"]=>
    string(0) ""
    ["TAS_DERIVATION_SCREEN_TPL"]=>
    string(0) ""
    ["TAS_SELFSERVICE_TIMEOUT"]=>
    int(0)
    ["TAS_SELFSERVICE_TIME"]=>
    string(0) ""
    ["TAS_SELFSERVICE_TIME_UNIT"]=>
    string(0) ""
    ["TAS_SELFSERVICE_TRIGGER_UID"]=>
    string(0) ""
    ["TAS_SELFSERVICE_EXECUTION"]=>
    string(10) "EVERY_TIME"
    ["TAS_TITLE"]=>
    string(8) "Level2-1"
    ["TAS_DESCRIPTION"]=>
    string(0) ""
    ["TAS_DEF_TITLE"]=>
    string(0) ""
    ["TAS_DEF_DESCRIPTION"]=>
    string(0) ""
    ["TAS_DEF_PROC_CODE"]=>
    string(0) ""
    ["TAS_DEF_MESSAGE"]=>
    string(0) ""
    ["TAS_DEF_SUBJECT_MESSAGE"]=>
    string(0) ""
    ["ASSIGNED_USERS"]=>
    array(0) {
    }
  }
  [2]=>
  array(55) {
    ["PRO_UID"]=>
    string(32) "525089953576c664761a208010895181"
    ["TAS_UID"]=>
    string(32) "830817043576c6a392aa197048151967"
    ["TAS_TYPE"]=>
    string(6) "NORMAL"
    ["TAS_DURATION"]=>
    float(1)
    ["TAS_DELAY_TYPE"]=>
    string(0) ""
    ["TAS_TEMPORIZER"]=>
    float(0)
    ["TAS_TYPE_DAY"]=>
    string(0) ""
    ["TAS_TIMEUNIT"]=>
    string(4) "DAYS"
    ["TAS_ALERT"]=>
    string(5) "FALSE"
    ["TAS_PRIORITY_VARIABLE"]=>
    string(0) ""
    ["TAS_ASSIGN_TYPE"]=>
    string(8) "BALANCED"
    ["TAS_ASSIGN_VARIABLE"]=>
    string(30) "@@SYS_NEXT_USER_TO_BE_ASSIGNED"
    ["TAS_GROUP_VARIABLE"]=>
    NULL
    ["TAS_MI_INSTANCE_VARIABLE"]=>
    string(24) "@@SYS_VAR_TOTAL_INSTANCE"
    ["TAS_MI_COMPLETE_VARIABLE"]=>
    string(34) "@@SYS_VAR_TOTAL_INSTANCES_COMPLETE"
    ["TAS_ASSIGN_LOCATION"]=>
    string(5) "FALSE"
    ["TAS_ASSIGN_LOCATION_ADHOC"]=>
    string(5) "FALSE"
    ["TAS_TRANSFER_FLY"]=>
    string(5) "FALSE"
    ["TAS_LAST_ASSIGNED"]=>
    string(1) "0"
    ["TAS_USER"]=>
    string(1) "0"
    ["TAS_CAN_UPLOAD"]=>
    string(5) "FALSE"
    ["TAS_VIEW_UPLOAD"]=>
    string(5) "FALSE"
    ["TAS_VIEW_ADDITIONAL_DOCUMENTATION"]=>
    string(5) "FALSE"
    ["TAS_CAN_CANCEL"]=>
    string(5) "FALSE"
    ["TAS_OWNER_APP"]=>
    string(5) "FALSE"
    ["STG_UID"]=>
    string(0) ""
    ["TAS_CAN_PAUSE"]=>
    string(5) "FALSE"
    ["TAS_CAN_SEND_MESSAGE"]=>
    string(4) "TRUE"
    ["TAS_CAN_DELETE_DOCS"]=>
    string(5) "FALSE"
    ["TAS_SELF_SERVICE"]=>
    string(5) "FALSE"
    ["TAS_START"]=>
    string(5) "FALSE"
    ["TAS_TO_LAST_USER"]=>
    string(5) "FALSE"
    ["TAS_SEND_LAST_EMAIL"]=>
    string(5) "FALSE"
    ["TAS_DERIVATION"]=>
    string(6) "NORMAL"
    ["TAS_POSX"]=>
    int(444)
    ["TAS_POSY"]=>
    int(257)
    ["TAS_WIDTH"]=>
    int(110)
    ["TAS_HEIGHT"]=>
    int(60)
    ["TAS_COLOR"]=>
    string(0) ""
    ["TAS_EVN_UID"]=>
    string(0) ""
    ["TAS_BOUNDARY"]=>
    string(0) ""
    ["TAS_DERIVATION_SCREEN_TPL"]=>
    string(0) ""
    ["TAS_SELFSERVICE_TIMEOUT"]=>
    int(0)
    ["TAS_SELFSERVICE_TIME"]=>
    string(0) ""
    ["TAS_SELFSERVICE_TIME_UNIT"]=>
    string(0) ""
    ["TAS_SELFSERVICE_TRIGGER_UID"]=>
    string(0) ""
    ["TAS_SELFSERVICE_EXECUTION"]=>
    string(10) "EVERY_TIME"
    ["TAS_TITLE"]=>
    string(8) "Level2-2"
    ["TAS_DESCRIPTION"]=>
    string(0) ""
    ["TAS_DEF_TITLE"]=>
    string(0) ""
    ["TAS_DEF_DESCRIPTION"]=>
    string(0) ""
    ["TAS_DEF_PROC_CODE"]=>
    string(0) ""
    ["TAS_DEF_MESSAGE"]=>
    string(0) ""
    ["TAS_DEF_SUBJECT_MESSAGE"]=>
    string(0) ""
    ["ASSIGNED_USERS"]=>
    array(0) {
    }
  }
  [3]=>
  array(55) {
    ["PRO_UID"]=>
    string(32) "525089953576c664761a208010895181"
    ["TAS_UID"]=>
    string(32) "377580518576c77b7de72c4073683346"
    ["TAS_TYPE"]=>
    string(6) "NORMAL"
    ["TAS_DURATION"]=>
    float(1)
    ["TAS_DELAY_TYPE"]=>
    string(0) ""
    ["TAS_TEMPORIZER"]=>
    float(0)
    ["TAS_TYPE_DAY"]=>
    string(0) ""
    ["TAS_TIMEUNIT"]=>
    string(4) "DAYS"
    ["TAS_ALERT"]=>
    string(5) "FALSE"
    ["TAS_PRIORITY_VARIABLE"]=>
    string(0) ""
    ["TAS_ASSIGN_TYPE"]=>
    string(8) "BALANCED"
    ["TAS_ASSIGN_VARIABLE"]=>
    string(30) "@@SYS_NEXT_USER_TO_BE_ASSIGNED"
    ["TAS_GROUP_VARIABLE"]=>
    NULL
    ["TAS_MI_INSTANCE_VARIABLE"]=>
    string(24) "@@SYS_VAR_TOTAL_INSTANCE"
    ["TAS_MI_COMPLETE_VARIABLE"]=>
    string(34) "@@SYS_VAR_TOTAL_INSTANCES_COMPLETE"
    ["TAS_ASSIGN_LOCATION"]=>
    string(5) "FALSE"
    ["TAS_ASSIGN_LOCATION_ADHOC"]=>
    string(5) "FALSE"
    ["TAS_TRANSFER_FLY"]=>
    string(5) "FALSE"
    ["TAS_LAST_ASSIGNED"]=>
    string(1) "0"
    ["TAS_USER"]=>
    string(1) "0"
    ["TAS_CAN_UPLOAD"]=>
    string(5) "FALSE"
    ["TAS_VIEW_UPLOAD"]=>
    string(5) "FALSE"
    ["TAS_VIEW_ADDITIONAL_DOCUMENTATION"]=>
    string(5) "FALSE"
    ["TAS_CAN_CANCEL"]=>
    string(5) "FALSE"
    ["TAS_OWNER_APP"]=>
    string(5) "FALSE"
    ["STG_UID"]=>
    string(0) ""
    ["TAS_CAN_PAUSE"]=>
    string(5) "FALSE"
    ["TAS_CAN_SEND_MESSAGE"]=>
    string(4) "TRUE"
    ["TAS_CAN_DELETE_DOCS"]=>
    string(5) "FALSE"
    ["TAS_SELF_SERVICE"]=>
    string(5) "FALSE"
    ["TAS_START"]=>
    string(5) "FALSE"
    ["TAS_TO_LAST_USER"]=>
    string(5) "FALSE"
    ["TAS_SEND_LAST_EMAIL"]=>
    string(5) "FALSE"
    ["TAS_DERIVATION"]=>
    string(6) "NORMAL"
    ["TAS_POSX"]=>
    int(732)
    ["TAS_POSY"]=>
    int(161)
    ["TAS_WIDTH"]=>
    int(110)
    ["TAS_HEIGHT"]=>
    int(60)
    ["TAS_COLOR"]=>
    string(0) ""
    ["TAS_EVN_UID"]=>
    string(0) ""
    ["TAS_BOUNDARY"]=>
    string(0) ""
    ["TAS_DERIVATION_SCREEN_TPL"]=>
    string(0) ""
    ["TAS_SELFSERVICE_TIMEOUT"]=>
    int(0)
    ["TAS_SELFSERVICE_TIME"]=>
    string(0) ""
    ["TAS_SELFSERVICE_TIME_UNIT"]=>
    string(0) ""
    ["TAS_SELFSERVICE_TRIGGER_UID"]=>
    string(0) ""
    ["TAS_SELFSERVICE_EXECUTION"]=>
    string(10) "EVERY_TIME"
    ["TAS_TITLE"]=>
    string(8) "Level3-2"
    ["TAS_DESCRIPTION"]=>
    string(0) ""
    ["TAS_DEF_TITLE"]=>
    string(0) ""
    ["TAS_DEF_DESCRIPTION"]=>
    string(0) ""
    ["TAS_DEF_PROC_CODE"]=>
    string(0) ""
    ["TAS_DEF_MESSAGE"]=>
    string(0) ""
    ["TAS_DEF_SUBJECT_MESSAGE"]=>
    string(0) ""
    ["ASSIGNED_USERS"]=>
    array(0) {
    }
  }
  [4]=>
  array(55) {
    ["PRO_UID"]=>
    string(32) "525089953576c664761a208010895181"
    ["TAS_UID"]=>
    string(32) "829431226576c77b833cc11086813686"
    ["TAS_TYPE"]=>
    string(6) "NORMAL"
    ["TAS_DURATION"]=>
    float(1)
    ["TAS_DELAY_TYPE"]=>
    string(0) ""
    ["TAS_TEMPORIZER"]=>
    float(0)
    ["TAS_TYPE_DAY"]=>
    string(0) ""
    ["TAS_TIMEUNIT"]=>
    string(4) "DAYS"
    ["TAS_ALERT"]=>
    string(5) "FALSE"
    ["TAS_PRIORITY_VARIABLE"]=>
    string(0) ""
    ["TAS_ASSIGN_TYPE"]=>
    string(8) "BALANCED"
    ["TAS_ASSIGN_VARIABLE"]=>
    string(30) "@@SYS_NEXT_USER_TO_BE_ASSIGNED"
    ["TAS_GROUP_VARIABLE"]=>
    NULL
    ["TAS_MI_INSTANCE_VARIABLE"]=>
    string(24) "@@SYS_VAR_TOTAL_INSTANCE"
    ["TAS_MI_COMPLETE_VARIABLE"]=>
    string(34) "@@SYS_VAR_TOTAL_INSTANCES_COMPLETE"
    ["TAS_ASSIGN_LOCATION"]=>
    string(5) "FALSE"
    ["TAS_ASSIGN_LOCATION_ADHOC"]=>
    string(5) "FALSE"
    ["TAS_TRANSFER_FLY"]=>
    string(5) "FALSE"
    ["TAS_LAST_ASSIGNED"]=>
    string(1) "0"
    ["TAS_USER"]=>
    string(1) "0"
    ["TAS_CAN_UPLOAD"]=>
    string(5) "FALSE"
    ["TAS_VIEW_UPLOAD"]=>
    string(5) "FALSE"
    ["TAS_VIEW_ADDITIONAL_DOCUMENTATION"]=>
    string(5) "FALSE"
    ["TAS_CAN_CANCEL"]=>
    string(5) "FALSE"
    ["TAS_OWNER_APP"]=>
    string(5) "FALSE"
    ["STG_UID"]=>
    string(0) ""
    ["TAS_CAN_PAUSE"]=>
    string(5) "FALSE"
    ["TAS_CAN_SEND_MESSAGE"]=>
    string(4) "TRUE"
    ["TAS_CAN_DELETE_DOCS"]=>
    string(5) "FALSE"
    ["TAS_SELF_SERVICE"]=>
    string(5) "FALSE"
    ["TAS_START"]=>
    string(5) "FALSE"
    ["TAS_TO_LAST_USER"]=>
    string(5) "FALSE"
    ["TAS_SEND_LAST_EMAIL"]=>
    string(5) "FALSE"
    ["TAS_DERIVATION"]=>
    string(6) "NORMAL"
    ["TAS_POSX"]=>
    int(732)
    ["TAS_POSY"]=>
    int(65)
    ["TAS_WIDTH"]=>
    int(110)
    ["TAS_HEIGHT"]=>
    int(60)
    ["TAS_COLOR"]=>
    string(0) ""
    ["TAS_EVN_UID"]=>
    string(0) ""
    ["TAS_BOUNDARY"]=>
    string(0) ""
    ["TAS_DERIVATION_SCREEN_TPL"]=>
    string(0) ""
    ["TAS_SELFSERVICE_TIMEOUT"]=>
    int(0)
    ["TAS_SELFSERVICE_TIME"]=>
    string(0) ""
    ["TAS_SELFSERVICE_TIME_UNIT"]=>
    string(0) ""
    ["TAS_SELFSERVICE_TRIGGER_UID"]=>
    string(0) ""
    ["TAS_SELFSERVICE_EXECUTION"]=>
    string(10) "EVERY_TIME"
    ["TAS_TITLE"]=>
    string(8) "Level3-1"
    ["TAS_DESCRIPTION"]=>
    string(0) ""
    ["TAS_DEF_TITLE"]=>
    string(0) ""
    ["TAS_DEF_DESCRIPTION"]=>
    string(0) ""
    ["TAS_DEF_PROC_CODE"]=>
    string(0) ""
    ["TAS_DEF_MESSAGE"]=>
    string(0) ""
    ["TAS_DEF_SUBJECT_MESSAGE"]=>
    string(0) ""
    ["ASSIGNED_USERS"]=>
    array(0) {
    }
  }
  [5]=>
  array(55) {
    ["PRO_UID"]=>
    string(32) "525089953576c664761a208010895181"
    ["TAS_UID"]=>
    string(32) "583266832576c77372a9b78024738757"
    ["TAS_TYPE"]=>
    string(6) "NORMAL"
    ["TAS_DURATION"]=>
    float(1)
    ["TAS_DELAY_TYPE"]=>
    string(0) ""
    ["TAS_TEMPORIZER"]=>
    float(0)
    ["TAS_TYPE_DAY"]=>
    string(0) ""
    ["TAS_TIMEUNIT"]=>
    string(4) "DAYS"
    ["TAS_ALERT"]=>
    string(5) "FALSE"
    ["TAS_PRIORITY_VARIABLE"]=>
    string(0) ""
    ["TAS_ASSIGN_TYPE"]=>
    string(8) "BALANCED"
    ["TAS_ASSIGN_VARIABLE"]=>
    string(30) "@@SYS_NEXT_USER_TO_BE_ASSIGNED"
    ["TAS_GROUP_VARIABLE"]=>
    NULL
    ["TAS_MI_INSTANCE_VARIABLE"]=>
    string(24) "@@SYS_VAR_TOTAL_INSTANCE"
    ["TAS_MI_COMPLETE_VARIABLE"]=>
    string(34) "@@SYS_VAR_TOTAL_INSTANCES_COMPLETE"
    ["TAS_ASSIGN_LOCATION"]=>
    string(5) "FALSE"
    ["TAS_ASSIGN_LOCATION_ADHOC"]=>
    string(5) "FALSE"
    ["TAS_TRANSFER_FLY"]=>
    string(5) "FALSE"
    ["TAS_LAST_ASSIGNED"]=>
    string(1) "0"
    ["TAS_USER"]=>
    string(1) "0"
    ["TAS_CAN_UPLOAD"]=>
    string(5) "FALSE"
    ["TAS_VIEW_UPLOAD"]=>
    string(5) "FALSE"
    ["TAS_VIEW_ADDITIONAL_DOCUMENTATION"]=>
    string(5) "FALSE"
    ["TAS_CAN_CANCEL"]=>
    string(5) "FALSE"
    ["TAS_OWNER_APP"]=>
    string(5) "FALSE"
    ["STG_UID"]=>
    string(0) ""
    ["TAS_CAN_PAUSE"]=>
    string(5) "FALSE"
    ["TAS_CAN_SEND_MESSAGE"]=>
    string(4) "TRUE"
    ["TAS_CAN_DELETE_DOCS"]=>
    string(5) "FALSE"
    ["TAS_SELF_SERVICE"]=>
    string(5) "FALSE"
    ["TAS_START"]=>
    string(5) "FALSE"
    ["TAS_TO_LAST_USER"]=>
    string(5) "FALSE"
    ["TAS_SEND_LAST_EMAIL"]=>
    string(5) "FALSE"
    ["TAS_DERIVATION"]=>
    string(6) "NORMAL"
    ["TAS_POSX"]=>
    int(406)
    ["TAS_POSY"]=>
    int(364)
    ["TAS_WIDTH"]=>
    int(110)
    ["TAS_HEIGHT"]=>
    int(60)
    ["TAS_COLOR"]=>
    string(0) ""
    ["TAS_EVN_UID"]=>
    string(0) ""
    ["TAS_BOUNDARY"]=>
    string(0) ""
    ["TAS_DERIVATION_SCREEN_TPL"]=>
    string(0) ""
    ["TAS_SELFSERVICE_TIMEOUT"]=>
    int(0)
    ["TAS_SELFSERVICE_TIME"]=>
    string(0) ""
    ["TAS_SELFSERVICE_TIME_UNIT"]=>
    string(0) ""
    ["TAS_SELFSERVICE_TRIGGER_UID"]=>
    string(0) ""
    ["TAS_SELFSERVICE_EXECUTION"]=>
    string(10) "EVERY_TIME"
    ["TAS_TITLE"]=>
    string(6) "Level1"
    ["TAS_DESCRIPTION"]=>
    string(0) ""
    ["TAS_DEF_TITLE"]=>
    string(0) ""
    ["TAS_DEF_DESCRIPTION"]=>
    string(0) ""
    ["TAS_DEF_PROC_CODE"]=>
    string(0) ""
    ["TAS_DEF_MESSAGE"]=>
    string(0) ""
    ["TAS_DEF_SUBJECT_MESSAGE"]=>
    string(0) ""
    ["ASSIGNED_USERS"]=>
    array(0) {
    }
  }
}
--------------




