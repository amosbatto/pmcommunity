<?php
namespace Services\Api\extraRest;
use \ProcessMaker\Services\Api;
use \Luracast\Restler\RestException;
use \G;
use \UsersPeer;
use \CasesPeer;
use \ProcessMaker\Project\Adapter;
use \ProcessMaker\BusinessModel\Validator;
use \ProcessMaker\Util\DateTime;



class Extra extends Api
{
    private $_keys;
    private $_values;
    
    function add($key, $value) {
       $this->_keys[] = $key;
       $this->_values[] = $value;      
    }
    
    function __construct() {
		//add code here to be executed automatically every time the class is instantiated.        
        
        //print "PATH_HOME:".PATH_HOME."<br>\nPATH_TRUNK:".PATH_TRUNK."<br>\nPATH_OUTTRUNK:".PATH_OUTTRUNK;
        require_once(PATH_TRUNK.'gulliver/system/class.rbac.php');
    }
    
    /**
     * Return case information (without task information), ignoring security restrictions
     * 
     * @url GET /case/:app_uid
     * 
     * @access protected
     *      
     * @param string $app_uid {@min 32}{@max 32}
     * @return array
     * 
     * @author Amos Batto <amos@processmaker.com>
     * @copyright Public Domain
     */
    public function getCaseInfo($app_uid)
    {  	
		try {	
			$g = new G();
			$g->loadClass("cases");
			$oCase = new \Cases();
			$aCaseInfo = $oCase->loadCase($app_uid);
			
			if (!is_array($aCaseInfo) or !isset($aCaseInfo['APP_UID'])) {
				throw new \Exception("Invalid app_uid");
		    } 
		} 
		catch (\Exception $e) {
            throw (new RestException(Api::STAT_APP_EXCEPTION, $e->getMessage()));
        }
		
        return $aCaseInfo;
    }
    
    /**
     * Return case and task information, ignoring security restrictions.
     * 
     * @url GET /case/:app_uid/:del_index
     * @access protected
     * 
     * @param string $app_uid {@min 32}{@max 32}
     * @param int $del_index 
     * @return array
     * 
     * @author Amos Batto <amos@processmaker.com>
     * @copyright Public Domain
     */
    public function getCaseInfoWithIndex($app_uid, $del_index)
    {  
        try {
			$g = new G();
			$g->loadClass("cases");
			$oCase = new \Cases();
			$aCaseInfo = $oCase->loadCase($app_uid, $del_index);
			
			if (!is_array($aCaseInfo) or !isset($aCaseInfo['APP_UID'])) {
				throw new \Exception("Invalid app_uid or del_index");
		    } 
		} 
		catch (\Exception $e) {
            throw (new RestException(Api::STAT_APP_EXCEPTION, $e->getMessage()));
        }
		
        return $aCaseInfo;
    }
    
    /**
     * Change the case's status from TO_DO to DRAFT or from DRAFT to TO_DO.
     * Logged-in user must either be the assigned user to specified delegation index or 
     * a process supervisor for the case's process. 
     * 
     * @url PUT /case/status/:app_uid
     * @access protected
     *
     * @param string $app_uid   Case ID. {@min 32}{@max 32} {@from path}
     * @param string $status    Case status to set. {@from body} {@choice TO_DO,DRAFT}
     * @param int    $del_index Optional delegation index. If not set, then the current delegation in case. {@from body}
     * 
     * @author Amos Batto <amos@processmaker.com>
     * @copyright Public Domain
     */
    public function putCaseStatus($app_uid, $status, $del_index=null) {  
		try {
			$g = new G();
			$g->loadClass("cases");
			$oCase = new \Cases();
			
			if (isset($del_index)) {
				$aCaseInfo = $oCase->loadCaseByDelegation($app_uid, $del_index);
			} else {
				$aCaseInfo = $oCase->loadCaseInCurrentDelegation($app_uid);
				$del_index = $aCaseInfo["DEL_INDEX"];
				$aCaseInfo = $oCase->loadCaseByDelegation($app_uid, $del_index);
			}
			
			if (!empty($aCaseInfo['DEL_FINISH_DATE'])) {
				throw new \Exception("Cannot change status because delegation $del_index is closed in case '$app_uid'.");
			}
			
			if ($aCaseInfo['USR_UID'] != $this->getUserId()) {
				if ($this->userCanAccess('PM_SUPERVISOR') == 0) {
					throw new \Exception("Logged-in user needs the PM_SUPERVISOR permission in role.");
				}
			}
			
			if ($aCaseInfo['APP_STATUS'] != 'TO_DO' and $aCaseInfo['APP_STATUS'] != 'DRAFT') {
				throw new \Exception("Case has status '{$aCaseInfo['APP_STATUS']}', so its status can't be changed.");
			}
			
			$aCaseInfo['APP_STATUS'] = $status;
			$oCase->updateCase($aCaseInfo);  
		} 
		catch (\Exception $e) {
            throw (new RestException(Api::STAT_APP_EXCEPTION, $e->getMessage()));
        }
		
        return null;
    }
    
    
    /**
     * Return the list of cases found under Home > Review for Process Supervisors.
     * 
     * @url GET /cases/review
     * @access protected
     * 
     * @return array
     * 
     * @author Amos Batto <amos@processmaker.com>
     * @copyright Public Domain
     */
    public function getCaseListForReview() {
		try {  
			$g = new G();
			$g->LoadClass("applications");
			
			if ($this->userCanAccess('PM_SUPERVISOR') == 0) {
				throw new \Exception("Logged-in user lacks the PM_SUPERVISOR permission in role.");
			}

			/*In /workflow/engine/classes/class.applications.php
			Applications::getAll(
				$userUid,
				$start = null,
				$limit = null,
				$action = null,
				$filter = null,
				$search = null,
				$process = null,
				$status = null,
				$type = null,
				$dateFrom = null,
				$dateTo = null,
				$callback = null,
				$dir = null,
				$sort = "APP_CACHE_VIEW.APP_NUMBER",
				$category = null,
				$configuration = true,
				$paged = true,
				$newerThan = '',
				$oldestThan = ''
			)*/
			$userId = $this->getUserId(); 
			
			$oApp = new \Applications();
			$aList = $oApp->getAll($userId, null, null, 'to_revise');
			return $aList['data'];
		} 
		catch (\Exception $e) {
            throw new RestException(Api::STAT_APP_EXCEPTION, $e->getMessage());
        }   
	}
	
	/**
     * Get information about the logged-in user
     * 
     * @url GET /login-user
     * @access protected
     *      
     * @return string
     * 
     * @author Amos Batto <amos@processmaker.com>
     * @copyright Public Domain
     */
    public function getLoginUser()
    {  	
		try {
			$g = new G();
			$g->loadClass("pmFunctions");
			$userId = $this->getUserId();
			$aInfo = array('uid' => $userId);
			$aInfo = array_merge($aInfo, PMFInformationUser($userId));
			return $aInfo;
        } 
		catch (\Exception $e) {
            throw new RestException(Api::STAT_APP_EXCEPTION, $e->getMessage());
        }
    }  
    
    /**
     * Set the login language in $_SESSION['SYS_LANG']
     * 
     * @url PUT /language/:lang
     * @access protected
     *
     * @param string $lang 
     * 
     * @author Amos Batto <amos@processmaker.com>
     * @copyright Public Domain
     */
    public function putSystemLanguage($lang)
    {  
		try {
			if (empty($lang) or trim($lang) == false) {
				throw new \Exception("System language cannot be empty.");
			}
		
			$_SESSION['SYS_LANG'] = $lang;
			return null;
        } 
		catch (\Exception $e) {
            throw new RestException(Api::STAT_APP_EXCEPTION, $e->getMessage());
        }
    } 
    
    /**
     * Get the login language stored in $_SESSION['SYS_LANG']
     * 
     * @url GET /language
     * @access protected 
     * 
     * @author Amos Batto <amos@processmaker.com>
     * @copyright Public Domain
     */
    public function getSystemLanguage($lang)
    {  
		try {
			if (!isset($_SESSION['SYS_LANG'])) {
				throw new \Exception("System language for login session does not exist.");
			}
				
			return $_SESSION['SYS_LANG'];
        } 
		catch (\Exception $e) {
            throw new RestException(Api::STAT_APP_EXCEPTION, $e->getMessage());
        }
    }
    
    /**
     * Return information about a case based on its case number 
     * and an optional delegation index number. 
     * Ex: /api/1.0/workflow/extrarest/case/number/221?index=3
     * 
     * @url GET /case/number/:app_number
     * @access protected
     * 
     * @param int $app_number
     * @param int $index {@from path}
     * @return array
     * 
     * @author Amos Batto <amos@processmaker.com>
     * @copyright Public Domain
     */
    public function getCaseFromNumber($app_number, $index=null)
    {  
        try {
			if ($this->userCanAccess('PM_CASES') == 0) {
				throw new \Exception("Logged-in user lacks the PM_CASES permission in role.");
			}
			
			$g = new \G();
			$g->loadClass("pmFunctions");
			$g->loadClass("cases");
			$oCase = new \Cases();
        
			$sql = "SELECT * FROM APPLICATION WHERE APP_NUMBER=" . $app_number;
			$aReturn = executeQuery($sql);
			
			if (!is_array($aReturn) or empty($aReturn)) {
				throw new \Exception("Unable to find case number '$app_number'.");
			}
			
		    if ($index === null) {
			   $aCaseInfo = $oCase->loadCase($aReturn[1]['APP_UID']);
			} else {
			   $aCaseInfo = $oCase->loadCase($aReturn[1]['APP_UID'], $index);
			}
			
			if (!is_array($aCaseInfo) or !isset($aCaseInfo['APP_UID'])) {
				throw new \Exception("Invalid app_uid or del_index");
		    } 
		} 
		catch (\Exception $e) {
            throw (new RestException(Api::STAT_APP_EXCEPTION, $e->getMessage()));
        }
		
        return $aCaseInfo;
    } 
    
    /**
     * Return the list of cases for a specified user without being that logged-in user
     * 
     * @url GET /cases/user/:user_uid
     * @access protected
     * 
     * @param string $user_uid User's unique ID. Set to 00000000000000000000000000000000 for logged-in user. {@from path} {@min 32} {@max 32}
     * @param int $start {@from query}
     * @param int $limit {@from query}
     * @param string $action {@from query} {@choice todo,draft,sent,unassigned,paused,completed,cancelled,search,simple_search,to_revise,to_reassign,all,gral,default} 
     * @param string $filter {@from query} {@choice read,unread,started,completed}
     * @param string $search String to search for. {@from query}
     * @param string $pro_uid Process unique ID. {@from query} {@min 32}{@max 32}
     * @param string $app_status Only used if action=search {@from query} {@choice TO_DO,DRAFT,PAUSED,CANCELLED,COMPLETED,ALL}
     * @param string $date_from YYYY-MM-DD {@from query}
     * @param string $date_to YYYY-MM-DD {@from query}
     * @param string $dir Ascending or descending sort order. {@from query} {@choice ASC,DESC}
     * @param string $sort Database field to sort by. {@from query}
     * @param string $cat_uid Category unique ID. {@from query} {@min 32}{@max 32}
     * @param boolean $configuration Set to 1 or 0. {@from query} {@from path}
     * @param boolean $paged Set to 1 or 0. {@from query} {@from path}
     * @param string $newer_than YYYY-MM-DD. Like date_from, but > not >=. {@from query}
     * @param string $older_than YYYY-MM-DD. Like date_to, but < not <=. {@from query}
     * 
     * @return array
     * 
     * @author Amos Batto <amos@processmaker.com>
     * @copyright Public Domain
     */
    public function getCasesForUser(
		$user_uid,                            //for the logged-in user, set to: 00000000000000000000000000000000 
		$start = null,
		$limit = null,
		$action = null, 
		$filter = null,
		$search = null,
		$pro_uid = null,                      //process unique ID
		$app_status = null,                   //only used if $action=='search'
		$date_from = null,
		$date_to = null,
		$dir = null,                          //ASC or DESC
		$sort = "APP_CACHE_VIEW.APP_NUMBER",
		$cat_uid = null,                      //category unique ID
		$configuration = true,                
		$paged = true,
		$newer_than = '',                     //same as $date_from, but > rather than >=
		$older_than = ''                      //same as $date_to, but < rather than <=
	) {
		try {  
			$type = null;                         //not setable parameter
			$callback = null;                     //not setable parameter
			
			$g = new G();
			$g->LoadClass("applications");

			if ($user_uid == 0) {
				$user_uid = $this->getUserId();
			}
			
			if ($this->userCanAccess('PM_CASES') == 0) {
				throw new \Exception("Logged-in user needs the PM_CASES permission in role.");
			}
			
			if ($user_uid != $this->getUserId() and $this->userCanAccess('PM_ALLCASES') == 0) {
				throw new \Exception("Logged-in user needs the PM_ALLCASES permission to access another user's cases.");
			} 
			
			//see Applications::getAll() defined in workflow/engine/classes/class.applications.php
			$oApp = new \Applications();
			$aList = $oApp->getAll(
				$user_uid, 
				$start,
				$limit,
				$action,
				$filter,
				$search,
				$pro_uid,
				$app_status,
				$type,
				$date_from,
				$date_to,
				$callback,
				$dir,
				$sort,
				$cat_uid,
				$configuration,
				$paged,
				$newer_than,
				$older_than
			);
			if ($paged) {
				return $aList;
			} else {
				return $aList['data'];
			}
		} 
		catch (\Exception $e) {
            throw new RestException(Api::STAT_APP_EXCEPTION, $e->getMessage());
        }   
	}
	
	/**
     * Execute an SQL SELECT query in the current workspace's workflow database. 
     * By default, the initial workspace is named "wf_workflow". The results
     * are returned in a numbered array starting from 1, just like executeQuery().
     * 
     * Note 1: For security reasons, this endpoint is commented out. If
     * you want to test it, then remove the comments and change the [AT] to @
     * It is strongly recommended to adapt this code to include the specific
     * SQL query that you need and only pass the specific parameters that
     * need to be changed to the endpoint. For security reasons, do not 
     * allow this endpoint to execute any SQL query. Its code is provided
     * to show you how to execute SQL queries in ProcessMaker, but it needs 
     * to be adapted for your specific purpose to make it safer. 
     * 
     * Note 2: Only SELECT statements in the current workspace's workflow
     * database are allowed. If thinking of modifying this endpoint to allow UPDATE, INSERT and DELETE
     * statements, then make sure to change the ProcessMaker configuration files. See:
     * http://wiki.processmaker.com/3.0/Consulting_the_ProcessMaker_databases#Protecting_PM_Core_Tables
     * 
     * 
     * [AT]url POST /sql
     * [AT]access protected
     * 
     * [AT]param string $sql SQL SELECT statement to execute. {@from body}
     *   
     * [AT]return array
     * 
     * [AT]author Amos Batto <amos@processmaker.com>
     * [AT]copyright Public Domain
     */
    /* 
    public function postSql($sql) {
		try {
			$g = new \G();
			$g->loadClass("pmFunctions");
			
			if (preg_match('/^\s*select\s/i', $sql) == 0) {
				throw new \Exception("SQL must be a SELECT statement.");
			} 
		
			$aResult = executeQuery($sql);
			
			$aRows = array();
			foreach ($aResult as $aRow) {
				$aRows[] = $aRow;
			}	
			return $aRows;
		} 
		catch (\Exception $e) {
            throw new RestException(Api::STAT_APP_EXCEPTION, $e->getMessage());
        }  
	}
	*/
	
	/**
	 * Function to replicate RBAC::userCanAccess()
	Note: Had to create this function to query DB, because can't use this header:
	[AT]class  AccessControl {@permission PM_USERS}
	because it redirects to http://{domain-or-ip}/loginForm.php 
	
	//This returns an empty array:
	$oPerm = new \ProcessMaker\Services\Api\Role\Permission();
	$oPerm->doGetPermissions($roleId);
	
	//and this doesn't work, because there is no global $RBAC:
	global $RBAC;
	if ($RBAC->userCanAccess('PM_USERS') == 1) {...}
	
	//and this causes an error:
	$rbac = \RBAC::getSingleton();
	$rbac->load($loggedUserId);
	
	//And this doesn't work either:   
    global $RBAC;
    if (!isset($RBAC)) {
		\Bootstrap::LoadSystem('rbac');
		$RBAC = \RBAC::getSingleton();
		$RBAC->sSystem = 'PROCESSMAKER';
		$RBAC->initRBAC();
		$RBAC->loadUserRolePermission($RBAC->sSystem, $userId);
    }
    $RBAC->userCanAccess('PM_SUPERVISOR');
        
    //this also doesn't work:    
    $r = new \RBAC();
    $aPerms = $r->loadUserRolePermission('PROCESSMAKER', $userId);
    $permissions = Util::nestedValue($userId, 'aUserInfo', 'PROCESSMAKER', 'PERMISSIONS');
	 */
	public function userCanAccess($permissionCode, $userId='') {
		if (empty($userId)) {
			$userId = $this->getUserId();
		}
		
		$oUser = new \RbacUsers();
		$aRole = $oUser->getUserRole($userId);
		$roleId = $aRole['ROL_UID'];
		
		$g = new \G();
		$g->loadClass('pmFunctions');
		
		$sql = "SELECT P.* FROM RBAC_ROLES_PERMISSIONS RP, RBAC_PERMISSIONS P 
			WHERE P.PER_CODE='$permissionCode' AND P.PER_UID=RP.PER_UID AND RP.ROL_UID='$roleId'";
		$aPerm = executeQuery($sql);
		
		return count($aPerm);
	}
	
    /**
     * Update user configuration stored in a serialized array in CONFIGURATION.CFG_VALUE. 
     * 
     * @url PUT /user/:usr_uid/config
     * @access protected
     * 
     * @param string $usr_uid User's unique ID. {@from path}{@min 32}{@max 32}
     * @param string $default_lang Default interface language in 'xx' or 'xx-CC' format. 
     *    {@from body} {@pattern /^[a-z]{2,3}([\-_][A-Z]{2})?$/}
     * @param string $default_menu Default main menu: '' (default for role), PM_CASES=Home, PM_FACTORY=Designer, PM_SETUP=Admin 
     *    {@from body} {@choice PM_CASES,PM_FACTORY,PM_SETUP,PM_DASHBOARD,} 
     * @param string $default_cases_menu Default Cases submenu: ''=default Inbox, CASES_SENT=participated, CASES_SELFSERVICE=unassigned, CASES_SEARCH=advanced search, CASES_TO_REVISE=review, CASES_FOLDERS=Documents 
     *    {@from body} {@choice CASES_START_CASE,CASES_INBOX,CASES_DRAFT,CASES_SENT,CASES_SELFSERVICE,CASES_PAUSED,CASES_SEARCH,CASES_TO_REVISE,CASES_TO_REASSIGN,CASES_FOLDERS,} 
     * 
     * @return array An array holding the updated user configuration.
     * 
     * @author Amos Batto <amos@processmaker.com>
     * @copyright Public Domain
     */
    public function putUserConfig($usr_uid, $default_lang=null, $default_menu=null, $default_cases_menu=null)
    {  
        try {
			$rbac = \RBAC::getSingleton();
			$rbac->initRBAC();
			
			if ($rbac->verifyUserId($usr_uid) != 1) {
				throw new \Exception("User with ID '$usr_uid' does not exist.");
			}
			
			if ($this->userCanAccess('PM_USERS') == 0) {
				throw new \Exception("Logged-in user lacks the PM_USERS permission in role.");
			}
			
			$g = new \G();
			$g->loadClass('configuration');
			$oConf = new \Configurations();
			$oConf->loadConfig($x, 'USER_PREFERENCES', '', '', $usr_uid, '' );
			
			//set user configuration:
			if (isset($default_lang)) {
				$oConf->aConfig['DEFAULT_LANG'] = $default_lang;
			}
			if (isset($default_menu)) {
				$oConf->aConfig['DEFAULT_MENU'] = $default_menu;
			}
			if (isset($default_cases_menu)) {
				$oConf->aConfig['DEFAULT_CASES_MENU'] = $default_cases_menu;
			}
			
			//update configuration:
			$oConf->saveConfig('USER_PREFERENCES', '', '', $usr_uid);
			
			$oConf->loadConfig($y, 'USER_PREFERENCES', '', '', $usr_uid, '');
			return $oConf->aConfig;
		} 
		catch (\Exception $e) {
            throw new RestException(Api::STAT_APP_EXCEPTION, $e->getMessage());
        }
    } 
    
    /**
     * Get user configuration stored in a serialized array in CONFIGURATION.CFG_VALUE. 
     * 
     * @url GET /user/:usr_uid/config
     * @access protected
     * 
     * @param string $usr_uid User's unique ID. {@from path}{@min 32}{@max 32}
     * 
     * @return array An array holding the user configuration.
     * 
     * @author Amos Batto <amos@processmaker.com>
     * @copyright Public Domain
     */
    public function getUserConfig($usr_uid) {  
        try {
			$rbac = \RBAC::getSingleton();
			$rbac->initRBAC();
			
			if ($rbac->verifyUserId($usr_uid) != 1) {
				throw new \Exception("User with ID '$usr_uid' does not exist.");
			}
			
			if ($this->userCanAccess('PM_USERS') == 0) {
				throw new \Exception("Logged-in user lacks the PM_USERS permission in role.");
			}
			
			$g = new \G();
			$g->loadClass('configuration');
			$oConf = new \Configurations();
			$oConf->loadConfig($x, 'USER_PREFERENCES', '', '', $usr_uid, '' );
			
			return $oConf->aConfig;
		} 
		catch (\Exception $e) {
            throw new RestException(Api::STAT_APP_EXCEPTION, $e->getMessage());
        }
    } 
    
    /**
     * Get a login session ID that can be attached to URLs used in ProcessMaker:
     * http://<address>/sys<workspace>/<lang>/<skin>/<folder>/<method>.php?sid=<session-id> 
     * Ex: http://example.com/sysworkflow/en/neoclassic/cases/cases_ShowDocument?a=4699401854d8262f569e9a1070221206&sid=1234567890abcde1234567890abcde 
     * 
     * @url GET /session-id
     * @access protected
     * 
     * @return string The session ID.
     * 
     * @author Amos Batto <amos@processmaker.com>
     * @copyright Public Domain
     */
    public function getSessionId() {  
        try {    
			$g = new G();
			$sessionId = $g->generateUniqueID();
			$userId = $this->getUserId();

            $session = new \Session();
            $session->setSesUid( $sessionId );
            $session->setSesStatus( 'ACTIVE' );
            $session->setUsrUid( $userId );
            $session->setSesRemoteIp( $_SERVER['REMOTE_ADDR'] );
            $session->setSesInitDate( date( 'Y-m-d H:i:s' ) );
            $session->setSesDueDate( date( 'Y-m-d H:i:s', mktime( date('H'), 
				date('i') + 15, date('s'), date('m'), date('d'), date('Y') ) ) );
            $session->setSesEndDate( '' );
            $session->Save();
            return $sessionId;
        } 
		catch (\Exception $e) {
            throw new RestException(Api::STAT_APP_EXCEPTION, $e->getMessage());
        }
    } 
    
    /**
     * Claim a case for the logged-in user where a task is unassigned because the task 
     * is Self Service or Self Service Value Based Assignment.
     * 
     * @url POST /case/:app_uid/claim
     * @access protected
     *
     * @param string $app_uid Case unique ID. {@from path}{@min 1}{@max 32}
     * @param int $del_index  Optional. The delegation index of the task to claim. 
     *  Only include if there are multiple open tasks in the case. {@from body}
     * @param string $usr_uid Optional. Unique ID of the user to assign to case. 
     *  Only include if the logged-in user is a process supervisor assigning another user {@from body}
     */
    public function postClaimCase($app_uid, $del_index = null, $usr_uid = null)
    {
        try {
            $loggedUserId = $this->getUserId();
            $oCase = new \Cases();
            
            if (empty($del_index)) {
               $del_index = $oCase->getCurrentDelegation($app_uid, '', true);
            }

            $oAppDel = new \AppDelegation();
            $aDelegation = $oAppDel->load($app_uid, $del_index);

            if ($aDelegation['USR_UID'] != '') {
				throw new \Exception("The task is already assigned to user with ID '{$aDelegation['USR_UID']}'."); 
			}
			
			if (empty($usr_uid) or $loggedUserId == $usr_uid) {
				$userIdToAssign = $loggedUserId;
			} 
			else {
				//check whether the user exists and has the PM_SUPERVISOR permission in role.
				$rbac = \RBAC::getSingleton();
				$rbac->initRBAC();
			
				if ($rbac->verifyUserId($usr_uid) != 1) {
					throw new \Exception("User with ID '$usr_uid' does not exist.");
				}
			
				if ($this->userCanAccess('PM_SUPERVISOR') == 0) {
					throw new \Exception("Logged-in user lacks the PM_SUPERVISOR permission in role.");
				}
				
				//check if logged-in user is assigned as a process supervisor to the process
				$oSuper = new \ProcessMaker\BusinessModel\ProcessSupervisor();
				$aSupervisorList = $oSuper->getProcessSupervisors($aDelegation['PRO_UID'], 'ASSIGNED');
				
				if (!isset($aSupervisorList['data']) or !is_array($aSupervisorList['data'])) {
					throw new \Exception("Unable to retrieve list of supervisors for process.");
				}
				$isSuperForProcess = false;
				
				foreach ($aSupervisorList['data'] as $aSupervisorInfo) {
					if ($aSupervisorInfo['usr_uid'] == $loggedUserId) {
						$isSuperForProcess = true;
						break;
					}
				}
				
				if ($isSuperForProcess === false) {
					throw new \Exception("User '$loggedUserId' must be assigned as a Supervisor for process '".
					   $aDelegation['PRO_UID']."'.");
				}	   
				$userIdToAssign = $usr_uid;
			}
            
            $oCase->setCatchUser($app_uid, $del_index, $userIdToAssign);
        } 
        catch (\Exception $e) {
            throw (new RestException(Api::STAT_APP_EXCEPTION, $e->getMessage()));
        }
    }  
}    

